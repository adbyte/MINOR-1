import 'package:flutter/material.dart';
import 'screens/sign_in_screen.dart';
import 'screens/sign_up_screen.dart';
import 'screens/brand_request_screen.dart';
import 'screens/influencer_list_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/brand_requests_screen.dart';
import 'screens/influencer_home_screen.dart'; 
import 'screens/influencer_signup_screen.dart';

void main() {
  runApp(const ClyxApp());
}

class ClyxApp extends StatelessWidget {
  const ClyxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Clyx',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const SignInScreen(), // Entry point set to SignInScreen
    );
  }
}
