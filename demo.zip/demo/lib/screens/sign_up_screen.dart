import 'dart:ui';
import 'package:flutter/material.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({Key? key}) : super(key: key);

  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  String? _selectedIndustry;
  final List<String> _industries = [
    'E-commerce and Online Retail',
    'Technology and Software',
    'Health and Wellness',
    'Sustainable and Eco-Friendly Products',
    'Fashion and Beauty Tech',
    'FinTech',
    'Gaming and eSports',
    'Streaming and Digital Media',
    'Electric Vehicles and Clean Energy',
    'Food Tech',
    'EdTech',
    'AR/VR and Metaverse',
    'Digital Content Creation and Influencer Platforms',
    'D2C Lifestyle Brands',
    'Pet Tech and Premium Pet Products',
    'Space Tech and Aerospace Innovations',
    'Travel Tech and Experiences',
    'AI and Data Analytics Solutions',
    'Luxury Tech',
    'Mobility Solutions',
    'Others'
  ];

  Widget _buildTextField(String label,
      {bool isPassword = false, TextInputType? keyboardType}) {
    return Container(
      height: 50,
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.purple, width: 1.5),
      ),
      child: TextFormField(
        obscureText: isPassword,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.purple),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20),
        ),
      ),
    );
  }

  Widget _buildDropdown() {
    return Container(
      height: 50,
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.purple, width: 1.5),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: DropdownButtonFormField<String>(
        value: _selectedIndustry,
        onChanged: (String? newValue) {
          setState(() {
            _selectedIndustry = newValue;
          });
        },
        items: _industries.map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
        decoration: const InputDecoration(
          labelText: 'Industry',
          labelStyle: TextStyle(color: Colors.purple),
          border: InputBorder.none,
        ),
        dropdownColor: Colors.white,
        icon: const Icon(Icons.arrow_drop_down, color: Colors.purple),
      ),
    );
  }

  Widget _buildGlowingButton(String label, VoidCallback onPressed) {
    return Container(
      height: 50,
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.purple, width: 1.5),
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
        ),
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            color: Colors.purple,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Sign Up',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.purple,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),
                _buildTextField('Brand Name'),
                _buildDropdown(),
                _buildTextField('Contact Person Name'),
                _buildTextField('Contact Email', keyboardType: TextInputType.emailAddress),
                _buildTextField('Contact Phone', keyboardType: TextInputType.phone),
                _buildTextField('Password', isPassword: true),
                const SizedBox(height: 16),
                _buildGlowingButton('Sign Up', () {
                  // Handle sign up logic
                  print('Sign Up clicked');
                }),
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text(
                    'Already have an account? Sign In',
                    style: TextStyle(color: Colors.purple),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
