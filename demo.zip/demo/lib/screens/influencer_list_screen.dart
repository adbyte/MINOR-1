import 'package:flutter/material.dart';
import 'profile_screen.dart'; // Import the ProfileScreen

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key});

  @override
  _ResultsScreenState createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  // Filter parameters
  double minFollowers = 0;
  double engagementRate = 0;
  List<String> selectedDemographics = [];
  double reputation = 5;

  // Demographics options
  final demographicsOptions = [
    "Teens",
    "Youngsters",
    "Adults",
    "Middle Aged",
    "Senior Citizens"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Results',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
            shadows: [
              Shadow(
                color: Colors.purpleAccent,
                blurRadius: 10,
              ),
            ],
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.purple,
        elevation: 4.0,
      ),
      endDrawer: Drawer( // Sidebar now slides in from the right
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              const Text(
                'Filters',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              // Follower Count Slider
              const Text('Minimum Follower Count:'),
              Slider(
                value: minFollowers,
                min: 0,
                max: 100,
                divisions: 20,
                label: '${minFollowers.round()}K',
                onChanged: (value) {
                  setState(() {
                    minFollowers = value;
                  });
                },
              ),
              const SizedBox(height: 16),
              // Engagement Rate TextField
              TextFormField(
                keyboardType: TextInputType.number,
                onChanged: (value) {
                  setState(() {
                    engagementRate = double.tryParse(value) ?? 0;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Engagement Rate (%)',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Demographics Checkboxes
              const Text('Audience Demographics:'),
              Column(
                children: demographicsOptions.map((demo) {
                  return CheckboxListTile(
                    title: Text(demo),
                    value: selectedDemographics.contains(demo),
                    onChanged: (isChecked) {
                      setState(() {
                        if (isChecked!) {
                          selectedDemographics.add(demo);
                        } else {
                          selectedDemographics.remove(demo);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              // Reputation Slider
              const Text('Reputation Parameter:'),
              Slider(
                value: reputation,
                min: 1,
                max: 10,
                divisions: 9,
                label: reputation.toStringAsFixed(1),
                onChanged: (value) {
                  setState(() {
                    reputation = value;
                  });
                },
              ),
              const SizedBox(height: 24),
              // Apply Filters Button
              ElevatedButton(
                onPressed: () {
                  // Apply filters and close drawer
                  Navigator.pop(context);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: const Text(
                  'Apply Filters',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        color: Colors.purpleAccent,
                        blurRadius: 10,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Search Bar with Modern Styling
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      spreadRadius: 2,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: const TextField(
                  decoration: InputDecoration(
                    hintText: 'Search influencers...',
                    prefixIcon: Icon(Icons.search, color: Colors.purple),
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 14),
                  ),
                ),
              ),
            ),
            // Influencer List
            Expanded(
              child: ListView.builder(
                itemCount: 10,
                itemBuilder: (context, index) {
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 4.0,
                    child: ListTile(
                      leading: CircleAvatar(
                        radius: 30,
                        backgroundImage:
                            NetworkImage('https://picsum.photos/seed/$index/200'),
                      ),
                      title: Text(
                        'Influencer ${index + 1}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      subtitle: Text(
                        'Followers: ${(index + 1) * 10}K',
                        style: const TextStyle(color: Colors.grey),
                      ),
                      trailing: ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ProfileScreen(
                                influencerName: 'Influencer ${index + 1}',
                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 8),
                          elevation: 3,
                        ),
                        child: const Text(
                          'View Profile',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.white,
                            shadows: [
                              Shadow(
                                color: Colors.purpleAccent,
                                blurRadius: 10,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
