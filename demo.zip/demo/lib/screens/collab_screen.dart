import 'package:flutter/material.dart';

class CollabScreen extends StatefulWidget {
  @override
  _CollabScreenState createState() => _CollabScreenState();
}

class _CollabScreenState extends State<CollabScreen> {
  // Dynamic list to hold brand requests
  List<Map<String, String>> _brandRequests = [];

  // Simulated API call to fetch brand requests
  Future<void> _fetchBrandRequests() async {
    await Future.delayed(const Duration(seconds: 2)); // Simulating network delay
    setState(() {
      _brandRequests = [
        {
          'brandName': 'EcoStyle',
          'niche': 'Sustainable Fashion',
        },
        {
          'brandName': 'FitFuel',
          'niche': 'Fitness Supplements',
        },
        {
          'brandName': 'TechTrendy',
          'niche': 'Gadgets & Accessories',
        },
        {
          'brandName': 'GlowCare',
          'niche': 'Skincare Products',
        },
      ];
    });
  }

  @override
  void initState() {
    super.initState();
    _fetchBrandRequests(); // Fetch data when the screen loads
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Collaborations',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: _brandRequests.isEmpty
          ? const Center(
              child: CircularProgressIndicator(), // Show loading indicator while fetching data
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: _brandRequests.length,
              itemBuilder: (context, index) {
                final request = _brandRequests[index];
                return _buildRequestCard(request);
              },
            ),
    );
  }

  // Method to build the collaboration request card widget
  Widget _buildRequestCard(Map<String, String> request) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      elevation: 3,
      margin: const EdgeInsets.only(bottom: 16.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  request['brandName'] ?? '',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  request['niche'] ?? '',
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
              ],
            ),
            ElevatedButton(
              onPressed: () {
                // Handle the accept offer action
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Offer from ${request['brandName']} accepted!'),
                  ),
                );

                // Remove the accepted request dynamically
                setState(() {
                  _brandRequests.remove(request);
                });
              },
              style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Accept'),
            ),
          ],
        ),
      ),
    );
  }
}
