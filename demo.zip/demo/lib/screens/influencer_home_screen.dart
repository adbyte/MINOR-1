import 'package:flutter/material.dart';
import 'collab_screen.dart'; // Import the CollabScreen file

class InfluencerHomeScreen extends StatefulWidget {
  @override
  _InfluencerHomeScreenState createState() => _InfluencerHomeScreenState();
}

class _InfluencerHomeScreenState extends State<InfluencerHomeScreen> {
  int _selectedIndex = 0; // Tracks the currently selected tab

  // List of screens for the bottom navigation
  final List<Widget> _screens = [
    HomeContent(), // The main content of the home screen
    CollabScreen(), // Collaboration screen
    ProfileScreen(), // Placeholder for the Profile screen
  ];

  void _onBottomNavTap(int index) {
    setState(() {
      _selectedIndex = index; // Update the selected tab
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex], // Display the currently selected screen
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onBottomNavTap, // Handle tab switching
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.purple,
        unselectedItemColor: Colors.grey,
        selectedFontSize: 14,
        unselectedFontSize: 12,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.add_circle_outline), label: 'Collaborations'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

// Home content as a separate widget
class HomeContent extends StatelessWidget {
  final List<Map<String, String>> _articles = [
    {
      'image': 'https://images.pexels.com/photos/3182834/pexels-photo-3182834.jpeg',
      'title': '10 Tips for Growing Your Social Media Presence',
      'description': 'Learn effective strategies to increase your followers and engagement on social media.',
      'content': 'Social media presence is crucial for growth. Begin by identifying your niche audience and create tailored, high-quality content regularly. Consistent engagement with your followers through comments, polls, and stories builds a loyal community. Additionally, analyze your analytics to identify what works best and collaborate with other influencers to widen your reach.'
    },
    {
      'image': 'https://images.pexels.com/photos/1181373/pexels-photo-1181373.jpeg',
      'title': 'The Future of Influencer Marketing',
      'description': 'Explore upcoming trends in influencer marketing and how to stay ahead of the curve.',
      'content': 'Influencer marketing is evolving with trends like AI-driven analytics, micro-influencers, and video-based content dominating the space. Authenticity and trust have become key metrics for brands when choosing influencers. Staying updated with industry trends and adapting to new platforms like TikTok or Threads ensures sustained relevance.'
    },
    {
      'image': 'https://images.pexels.com/photos/3184306/pexels-photo-3184306.jpeg',
      'title': 'Building Brand Collaborations',
      'description': 'Discover how to collaborate with brands to create impactful campaigns.',
      'content': 'Effective brand collaborations begin with understanding the brand’s goals and values. Pitch unique campaign ideas that align with their target audience. Always maintain transparency about deliverables and timelines. Showcase past successes to build trust and secure long-term partnerships.'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: _articles.length,
      itemBuilder: (context, index) {
        final article = _articles[index];
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => FullArticleScreen(article: article),
              ),
            );
          },
          child: _buildArticleCard(article),
        );
      },
    );
  }

  // Method to build the article card widget
  Widget _buildArticleCard(Map<String, String> article) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      elevation: 3,
      margin: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Image.network(
              article['image']!,
              height: 180,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  article['title']!,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  article['description']!,
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Full article screen
class FullArticleScreen extends StatelessWidget {
  final Map<String, String> article;

  const FullArticleScreen({Key? key, required this.article}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Article Details',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(
              article['image']!,
              height: 250,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    article['title']!,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    article['description']!,
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    article['content']!,
                    style: const TextStyle(fontSize: 16, color: Colors.black),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Placeholder for the profile screen
class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'Profile Screen',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }
}
